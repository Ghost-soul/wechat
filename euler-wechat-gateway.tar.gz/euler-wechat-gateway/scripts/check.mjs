// Read-only capabilities check. Does not inspect secrets, install, bind ports, or mutate host configuration.
import { execFileSync } from 'node:child_process';
console.log('Node:',process.version,'platform:',process.platform,'arch:',process.arch);
try { await import('node:sqlite'); console.log('node:sqlite available'); } catch { console.log('node:sqlite unavailable; Node 24 required'); process.exitCode=1; }
for(const [name,args] of [['uname',['-sr']],['python3',['--version']],['docker',['--version']],['hermes',['--version']]]){try{console.log(name+': '+execFileSync(name,args,{encoding:'utf8',timeout:5000,stdio:['ignore','pipe','pipe']}).trim());}catch{console.log(name+': unavailable');}}
