# Docker deployment variant (prepared; not deployed)

This avoids installing Node on the existing Linux host and leaves its Python and Hermes installation unchanged. Official `node:24-bookworm-slim` is verified in the [Docker Official Image listing](https://hub.docker.com/_/node) and maintained in [nodejs/docker-node](https://github.com/nodejs/docker-node). The tag may move: record the resolved digest at deployment and use that verified `node@sha256:…` as `NODE_IMAGE` for reproducible rebuilds. No digest has been invented or remotely pulled here.

## Security and storage

- Runtime user is UID/GID 1000, never root. Root steps in the Dockerfile only create private directories inside the image during build.
- Read-only image, dropped capabilities, no-new-privileges, bounded memory/processes, dedicated named volume, no Docker socket mount, no Hermes/config/home mount, no host networking.
- Relay listens on container `0.0.0.0:8080` so Docker can forward it. The host publishes **127.0.0.1 only** on an explicitly selected unused port. Do not run the container with `-p PORT:8080`, host networking, or a public bind override.
- Docker Engine 28+ is required for this loopback-publication security assumption: Docker documents a localhost-port exposure issue to same-L2 hosts on older releases. On older hosts, stop and choose an separately approved mitigation; do not change firewall rules or upgrade Docker silently. Source: https://docs.docker.com/engine/network/port-publishing/
- A host-based, separately approved HTTPS reverse proxy must forward only POST `/v1/relay` to the loopback port. A proxy in another container cannot reach host loopback automatically; do not broaden network access as a shortcut.
- Named volume `euler-wechat-bridge_relay_state` is new and dedicated, seeded from the image's private directory. Startup checks 0700 ownership; it fails if ownership does not match. This is persistent Docker-managed storage, not encrypted disk. Signing secrets inside SQLite are encrypted; messages are plaintext under filesystem protection.
- Approved secret files are bind-mounted read-only and must already exist as regular files owned by container UID 1000 with mode 0600. On rootless/user-namespace Docker, UID mapping must first be checked; do not relax permissions to make it work. Configure secret delivery with the actual namespace mapping. Compose bind mounts avoid unsupported assumptions about Compose secret uid/mode remapping.
- There is no restart policy by default. Operator validates first; persistent auto-start requires approval. An unclean stop leaves a lock; confirm no previous process/container is running before approved recovery of that lock. Never remove the volume or use `down -v` to recover.

## Minimal remaining host information

Docker daemon version/access and existing container names/ports are already requested. Also obtain `docker compose version` once to check Compose support. If Docker is unavailable to the current account, don't add it to the docker group or use sudo automatically. Existing service/port checks must include host services before choosing a port, not only `docker ps`.

The host Hermes version has now been supplied. No further Hermes version diagnostic is needed for the standalone adapter. Do not print `.env`, account JSON, tokens, or setup QR material into chat. The standalone adapter needs no Hermes dependency inspection. Do not run the normal Hermes gateway as a substitute: it may invoke its own agent rather than current Euler.

## Authorized deployment sequence (not executed here)

Use a fresh extracted package directory. Fill `docker.env` from `docker.env.example` with only paths/nonsecret config after credential/access approval; do not overwrite any existing environment file. Keep both secrets outside the build context. The Docker ignore file allowlists source/tests only.

After Docker 28+, Compose, the unused port, secret ownership and Site server-only forwarding are verified:

1. `docker compose --env-file docker.env config --quiet` (validates config; does not deploy)
2. `docker pull node:24-bookworm-slim`, then `docker image inspect node:24-bookworm-slim --format '{{json .RepoDigests}}'` (record actual official-image digest and set NODE_IMAGE to that verified digest; requires authorized software installation)
3. `docker compose --env-file docker.env build --pull relay` (builds from the pinned official image and runs all tests inside the image; requires authorized software execution)
4. `docker compose --env-file docker.env up -d --no-build relay` (explicit deployment approval required)
5. `docker compose --env-file docker.env ps` and verify unauthenticated loopback request returns 401; externally verify HTTPS and denied auth without printing credentials
6. Test synthetic subscription/challenge, event receipt in the existing Euler chat, reply recording, restart and unsubscribe before any real WeChat activation

No production credentials, account login, host deployment, image pull or Docker build was performed while preparing this archive. Local Node unit tests and YAML structure checks passed; Docker is absent from the preparation environment, so Compose validation and image build/runtime remain unverified until executed on the confirmed host.

## Real-WeChat readiness

The standalone text-only iLink adapter is implemented; see REAL_WECHAT.md. It does not depend on Hermes/Python or launch a model. Activation still requires approved account/persistent-access handoff and exact allowed sender IDs. No live WeChat or Euler callback integration has been verified. For the confirmed existing Caddy container, use compose.caddy.yaml and CADDY_DEPLOYMENT.md rather than the host-loopback variant.
