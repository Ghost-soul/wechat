import test from 'node:test';
import assert from 'node:assert/strict';
import { isPublicIPv4, validateCallback, pinnedOptions } from '../webhook-transport.mjs';
test('private, special and all IPv6 addresses fail closed', () => {
  for (const ip of ['0.0.0.0','10.0.0.1','100.64.0.1','127.0.0.1','169.254.169.254',
    '172.16.0.1','192.168.1.1','192.0.2.1','198.18.0.1','198.51.100.1','203.0.113.1',
    '224.0.0.1','255.255.255.255','::1','::ffff:127.0.0.1','2606:4700:4700::1111']) {
    assert.equal(isPublicIPv4(ip), false, ip);
  }
  assert.equal(isPublicIPv4('1.1.1.1'), true);
});
test('URL confusion and local targets rejected', () => {
  for (const url of ['http://example.com','https://user:pass@example.com','https://example.com:444',
    'https://example.com/#x','https://127.0.0.1','https://0x7f000001','https://2130706433',
    'https://[::1]','https://localhost','https://example.com.']) assert.throws(() => validateCallback(url));
});
test('pin connection IP while retaining original TLS name and HTTP Host', () => {
  const headers = {'webhook-id':'evt_1','webhook-timestamp':'1','webhook-signature':'v1,x','X-MCP-Subscription-Id':'sub_1'};
  const url = validateCallback('https://example.com/path?q=1');
  const o = pinnedOptions(url, ['1.1.1.1'], Buffer.from('{}'), headers);
  assert.equal(o.hostname, '1.1.1.1'); assert.equal(o.servername, 'example.com');
  assert.equal(o.headers.Host, 'example.com'); assert.equal(o.path, '/path?q=1');
  assert.equal(o.rejectUnauthorized, true); assert.equal(o.agent, false);
  assert.throws(() => pinnedOptions(url, ['1.1.1.1','10.0.0.1'], Buffer.from('{}'), headers));
  assert.throws(() => pinnedOptions(url, [], Buffer.from('{}'), headers));
});
