# Existing Caddy-container deployment plan

Confirmed host: Docker 29.1.3, Compose 2.40.3, existing `xs-agent-proxy-1` uses `caddy:2-alpine`, public ports 80/443, and mounts `/home/g2391299238zyx/xs-agent/Caddyfile` read-only. Existing apps use localhost8000/8081. User selected `wechat.331300.xyz`; DNS configuration is user-reported, not independently verified here.

Use `compose.caddy.yaml` instead of `compose.yaml`: it publishes **no host port** and attaches only to a dedicated `euler-wechat-ingress` network. Existing Caddy can reach `relay:8080` when explicitly attached to this network. Never proxy to `127.0.0.1` from inside Caddy expecting host loopback.

This plan requires confirmation before persistent networking, Caddy edits/reload and deployment. No such changes have been performed. The exact commands below are for the authorized operator after reviewing the existing Caddyfile and network names; do not paste them blindly.

1. Verify DNS A resolves to the GCP host and the existing Caddyfile has no conflicting site block. Read the existing file before any edit; preserve all original content and keep an operator-controlled backup. Do not overwrite it with this snippet.
2. Create dedicated network `docker network create euler-wechat-ingress` only if no existing network with this name is present. Confirm its scope/owner if it exists. Attach the Caddy container with `docker network connect euler-wechat-ingress xs-agent-proxy-1`. This live attachment must later be represented in the existing xs-agent Compose source with explicit approval so a Caddy recreation preserves it; never edit that source speculatively.
3. Prepare new package directory and approved gateway secret/key files. Fill nonsecret config paths. Run `docker compose -f compose.caddy.yaml --env-file docker.env config --quiet`, then authorized build and up commands from DOCKER.md with `-f compose.caddy.yaml` included. No `RELAY_HOST_PORT` is needed for this variant.
4. Add this proposed **new site block** to a reviewed copy of the existing Caddyfile (no existing blocks removed):

```
wechat.331300.xyz {
    @relay {
        method POST
        path /v1/relay
    }
    handle @relay {
        request_body {
            max_size 32KB
        }
        reverse_proxy relay:8080
    }
    handle {
        respond 404
    }
}
```

No access log directive is included; ensure existing global logging does not capture Authorization or bodies. Backend enforces the gateway-only bearer. Validate the full candidate file with the actual installed Caddy binary before applying and reloading; do not restart/delete the proxy, its volumes or the other services. The `caddy:2-alpine` tag alone does not prove its exact runtime version; candidate validation is required.

5. Verify the original applications remain reachable; unauthenticated POST to `https://wechat.331300.xyz/v1/relay` should return 401 and other paths should return 404. Do not put credentials in URLs or shell history. Supply any authenticated test token through owner-only file/stdin mechanisms.
6. Only after synthetic end-to-end success and separate WeChat-account approval add the optional `-f compose.wechat.yaml` overlay as described in REAL_WECHAT.md.

Rollback: remove only this new site block and dedicated network attachment after confirmation; retain the bridge state volume and encrypted subscription data for recovery. Do not use `docker compose down -v` or touch existing Hermes/Caddy data.
