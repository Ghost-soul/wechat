# Real text-only iLink adapter

Implemented in `ilink.mjs`; activation is gated, implementation is not a stub. It runs independently of installed Hermes or Python, without a model, prompts, plugins, or subprocesses. It uses Hermes upstream's documented iLink transport protocol (attribution/license in THIRD_PARTY_NOTICES.md): fixed `https://ilinkai.weixin.qq.com/ilink/bot/getupdates` and `/sendmessage`, channel version 2.2.0. No caller-selected host, redirects or media fetching is possible.

Receive scope: explicit inbound-user/completed message types, exactly one plain text item, exact allowlisted sender, no groups, bot echoes, references or media. Messages lacking stable provider message ID or context token are dropped. Observed-receipt UTC time is used for event timestamps because this bounded adapter does not assume undocumented upstream timestamp units.

The received polling cursor, encrypted per-peer context token, normalized message and event queue are committed in one SQLite transaction. Provider message IDs deduplicate across restarts. Text-only repeated messages with different provider IDs remain separate; it does not wrongly suppress intentional repeated text. Cursor storage is encrypted and never returned by tools.

Outgoing replies require a tool call naming an existing allowlisted message. At most one reply per message; same text is idempotent, different text is rejected. Only one text bubble of at most 1000 characters is supported. Send state is persisted before network I/O. Provider `ret:0` yields `sent`; a rejected response yields `provider_rejected`. Timeout/disconnect/ambiguous response or restart during sending yields `uncertain` and never auto-retries. A stable client ID is supplied but provider exactly-once semantics are not assumed. User/operator reconciliation is required before another attempt; no automatic resend or tokenless fallback.

## Activation gate

After explicit account/persistent-access approval, the user creates or supplies a dedicated owner-only credential file through secure login/handoff, not chat. JSON shape: `account_id`, `token`, optional `base_url` (if present must equal `https://ilinkai.weixin.qq.com`). No real token is provided in this package. QR login/account creation is a separate secure user step; this package deliberately does not auto-run Hermes setup or scrape its credentials.

Only after that user step:
- `WECHAT_ENABLE=approved`
- `WECHAT_ACCOUNT_HOST_FILE` names the private credential JSON, UID 1000/mode0600 (or mapped equivalent)
- `WECHAT_ALLOWED_SENDERS` lists exact approved sender IDs, comma-separated
- Add `-f compose.wechat.yaml` after the chosen base compose file

Do not run two pollers for the same iLink bot token. A dedicated bot/account is preferred. If reusing a Hermes-connected account, confirm it is not actively polled and obtain explicit approval for any change; never stop the user's existing Hermes service silently. The bridge neither reads nor mounts the Hermes home directory.

No installed Hermes version dependency remains. The user's Hermes v0.21.5 version is useful only if its existing account/setup is chosen for the separate secure handoff; standalone transport implementation does not depend on that installation.

## Plugin contract

When activated, backend catalog additionally includes:
- Event `wechat.message.created`, empty filter arguments, payload `{message_id,sender_id,text}`
- Tool `list_wechat_messages({})`: last 20 messages and reply states
- Tool `reply_to_wechat_message({message_id,reply})`: queue/idempotent status; `sent_to_wechat` is true only when previously confirmed sent
- `get_status` reports adapter state and recent successful polling; configured is not connected

Synthetic tools/event remain available. WeChat text is untrusted external data, never instructions to override the subscribed Euler's policy. The user must explicitly authorize the standing reply behavior/recipient scope in current Euler before enabling automatic replies.

## Staged success checks

1. Bring up the isolated relay without the WeChat overlay; wrong/missing auth returns 401 and HTTPS through wechat.331300.xyz succeeds
2. Securely provision Site's matching gateway-only bearer; subscribe and complete a synthetic round trip in the current Euler chat
3. Complete approved QR/account handoff, bind exact allowlisted sender, activate overlay, verify adapter status reports a recent successful poll
4. Send one plain DM from that sender; check a single event reaches current Euler, not another agent
5. Ask Euler for one bounded reply; verify provider acceptance and actual receipt in WeChat. Repeat tool call to confirm no duplicate send
6. Restart, verify cursor/context/dedup survival; test unknown sender, group, media and own echo are not forwarded; unsubscribe stops callback delivery

Offline fixture tests cover these protocol/state paths. Live Tencent login, TLS, account entitlement, real payload compatibility and end-to-end Euler wake/reply are not yet verified. Unknown/changed provider envelopes fail closed and need diagnosis with redacted metadata, never raw tokens or message payload logs.

## Revocation

Authenticated backend-only JSON-RPC `bridge/disconnect` with params `{}` is not advertised as an MCP tool. It idempotently persists disconnection, removes subscriptions, cancels pending deliveries and unsent replies, aborts/awaits adapter loops, and disables subsequent mutations across restarts. Already in-flight external sends may have completed. Site should delete its stored bearer only after this operation confirms success; if unreachable, report that backend revocation is unconfirmed. Re-entry of the same token does not resume the persisted disabled state; operator-approved reactivation is separate.
