# Euler private WeChat bridge: conventional Node backend

For the confirmed Linux host without Node, use the prepared [Docker variant](DOCKER.md). No host Node installation is required.

## Status and boundary

This is an **offline-prepared, not deployed** backend package. The MCP event path and text-only iLink adapter are implemented and fixture-tested. It does **not** connect a WeChat account, call any model, start Hermes, create credentials, alter firewall rules or replace any existing service. No production secret is included. Node 24 (with built-in `node:sqlite`), a persistent disk and outbound public DNS/HTTPS are required. There are no npm dependencies or install scripts.

The intended path is: current Euler's private Site MCP endpoint → authenticated, fixed Node relay → durable subscription/queue → signed ChatGPT callback → current subscribed Euler chat. Replies return through the same Site to the queue. No separate Hermes model/session is introduced. The Node endpoint is not a standalone public MCP service and must not be connected directly as an unauthenticated plugin.

The existing Site must keep its owner authentication and proxy ONLY supported MCP requests, with an approved relay credential read exclusively from a supported server-side secret mechanism. Server-side secret forwarding has **not been verified**. The Site continues to fail closed until that mechanism, the credential provision and the destination host have been approved and tested. Do not put this bearer token in browser code, query strings, source control or public settings.

## Included implementation

- Single-owner SQLite state: subscriptions, message dedup, callback queue and reply queue persist across restarts. State is bound to the configured owner, and refuses another owner.
- Signed callback challenge before activation; deterministic subscription identity; finite ≤24-hour lifetimes; refresh/key-rotation window; idempotent unsubscribe; no replay claimed (`cursor: null`).
- Exact-byte Standard Webhooks HMAC-SHA256 signing. AES-256-GCM encrypted signing secrets using a separately provisioned key. Message text remains readable in the private SQLite file, so disk access and backups are sensitive.
- Public-IPv4 DNS pinning, original-host TLS verification, HTTPS/443 only, no redirects, bounded body/response/header sizes/timeouts. IPv6-only and special-use targets fail closed. The transport module is copied from the previously prepared conventional Node module.
- Bounded callback retries with stable event ID, fresh signatures and persisted backoff; 410 stops the subscription; 413 and other non-retryable errors stop delivery. A crash after receiver acceptance may redeliver the same event ID; exactly-once callback delivery is not claimed.
- Replies are idempotent per message. Different second replies fail rather than overwriting. Synthetic replies are recorded only. Real replies remain blocked before activation; afterward they follow durable pending/sending/sent/uncertain states, with no blind resend after ambiguity.
- No media, groups, arbitrary URL relay, shell execution endpoint, credential setup endpoint or model API.

## Real WeChat text transport implemented, activation gated

See [REAL_WECHAT.md](REAL_WECHAT.md) for the implemented standalone iLink receiver/sender, supported text-DM scope, durable cursor/context handling and account approval requirements. It does not import or start Hermes and does not call any model. WeChat remains disabled until the user securely provisions a dedicated account credential file, explicit sender allowlist and activation approval. No live account was connected during preparation.

For the user's existing containerized Caddy and selected `wechat.331300.xyz` hostname, use [CADDY_DEPLOYMENT.md](CADDY_DEPLOYMENT.md) and `compose.caddy.yaml`. The default compose file is a separate loopback-publication variant; do not combine both base files.

Primary references checked:
- https://developers.openai.com/plugins/build/mcp-events
- https://github.com/NousResearch/hermes-agent/blob/main/website/docs/user-guide/messaging/weixin.md
- https://github.com/NousResearch/hermes-agent/blob/main/gateway/platforms/weixin.py
- https://nodejs.org/api/https.html

## Deployment plan (not an automated installer)

1. Use the user's approved existing GCP host; confirm OS/architecture, Node version, current services, free disk and a chosen unused unprivileged loopback port. `node scripts/check.mjs` is read-only and prints version information only. Do not run installs/upgrades automatically.
2. Copy this package to a new dedicated directory. Run `npm test`. Node 24 is required; `node:sqlite` availability must be checked. No `npm install` is required.
3. Agree on a separate service account, dedicated 0700 state directory, disk backup/retention, quota monitoring and supervisor. Run only one process, never a cluster. Existing Hermes paths/configuration must remain untouched.
4. With user action-time approval, provision a unique strong relay token (base64url 43–128 characters) and independent 32-byte encryption key encoded as standard base64. Provide each through a distinct owner-only 0600 regular file, owned by the service account. This package never generates or saves them. Site server-side storage receives only the relay token through its approved secret mechanism; the state key stays on the host. No shared secret should be typed in chat.
5. Configure these environment variable **file paths/nonsecret values**, without embedding secret values:
   - `RELAY_ENABLE=approved` only after the preceding access/secret approval and forwarding check
   - `RELAY_TOKEN_FILE=/absolute/owner-only/token-file`
   - `STATE_KEY_FILE=/absolute/owner-only/key-file`
   - `RELAY_OWNER=<the fixed verified Site owner principal>`
   - `RELAY_STATE_DIR=/absolute/new/private/state-directory`
   - `RELAY_PORT=<verified-unused-port>`
   - Leave `WECHAT_ENABLE` unset
6. Start with `node server.mjs`. It defaults to `127.0.0.1` and fails if the port is occupied. The Docker variant explicitly uses an internal container bind with loopback-only host publication; see DOCKER.md. A process lock prevents accidental multiple instances. On unclean exit, confirm the prior process is dead before manually removing its stale lock. Do not delete the database or rotate its key casually.
7. An existing or separately approved HTTPS reverse proxy must expose **only POST /v1/relay** at a fixed dedicated hostname/path, forward Authorization unchanged, impose a 32 KiB body limit, request/concurrency/rate limits, and disable body/header logs. Public TLS is required even though the process's local loopback hop is HTTP. No CORS/browser API is intended. Certificate installation, new firewall access, network policy and persistent service installation need their corresponding approval; this package changes none of them.
8. Site server makes only authenticated JSON-RPC requests to the fixed relay URL. It must never accept a destination from browser input, forward caller-supplied owner identity, or expose the relay token. The Node backend fixes ownership from config and ignores caller identity headers.
9. Verify rejected missing/wrong auth and unsupported paths from outside; verify TLS; then challenge/subscribe, synthetic event wake in current Euler, idempotent synthetic reply, restart/refresh/unsubscribe and negative sender/filter tests. Only then activate and test the separately gated WeChat account.

## Relay contract

`POST /v1/relay`, `Content-Type: application/json`, `Authorization: Bearer <approved token>`.
Body is JSON-RPC 2.0 with method and params. Supported methods: `server/discover`, `tools/list`, `events/list`, `events/subscribe`, `events/unsubscribe`, `tools/call`, `ping`. Synthetic tool names match the current Site: `get_status`, `list_test_messages`, `create_test_message({request_id})`, `reply_to_test_message({message_id,reply})`. Event name and schema match `test.message.created`: `{message_id,text,demo:true}`. The Site must relay all these state-bearing calls consistently; do not mix Site-D1 and Node message identities.

The bearer is the single-owner service-to-service authorization. It is not itself proof of originating Site network identity; keep it confidential and use provider-supported ingress restrictions/mTLS if later approved. Identity headers from public requests do not authorize Node access.

## Operational limits and acceptance gaps

- Unit tests exercise injected callback responses, not live DNS/TLS/ChatGPT. Live rebinding, certificate mismatch, timeout/response-limit behavior and the actual callback acceptance/wake are not yet tested.
- SQLite persistent disk and one process only. No horizontal scaling, distributed leases or crash-safe external WeChat sends are claimed.
- There is no automatic retention deletion. Hard limits are 10,000 messages and 16 subscriptions per state directory; hitting a limit fails closed until the owner approves maintenance. The small initial private pilot must have disk monitoring and owner-approved retention/export rules before sustained use. Event retries stop after five attempts; failed rows remain inspectable locally and do not silently claim successful delivery.
- Expired/revoked subscriptions stop sending. Live changes to global owner/credential authorization require restarting or disabling the private relay at the proxy; do not keep an old approved bearer active after revocation.
- Snapshot DB with a SQLite-safe backup process; protect backup permissions and state key independently. Losing the key requires revoking/recreating subscriptions, not treating ciphertext as usable state.
- Successful HTTP callback acceptance is not evidence of Euler responding; confirm the subscribed chat and reply tool separately.
