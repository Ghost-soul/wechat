# iLink protocol attribution

The text-only JavaScript transport in ilink.mjs adapts protocol constants, headers and message envelopes from NousResearch/hermes-agent's gateway/platforms/weixin.py. It does not import or launch Hermes, or include model logic.

Source: https://github.com/NousResearch/hermes-agent/blob/main/gateway/platforms/weixin.py
Retrieved 2026-09-30; downloaded source SHA-256: e0c366634c21a39aa5f21c32e8c1e91dae1cbd548d9d5d9192a9e65f8cbabb91
License source: https://github.com/NousResearch/hermes-agent/blob/main/LICENSE

MIT License

Copyright (c) 2025 Nous Research

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
