// Conventional Node.js only. NOT compatible with Workers' fetch-backed node:https.
import { Resolver } from 'node:dns/promises';
import { request } from 'node:https';
import { BlockList, isIP } from 'node:net';

const blocked = new BlockList();
// Conservative IANA special-use denylist; includes globally reachable special-use
// exceptions intentionally. IPv6 is deliberately unsupported, not incompletely filtered.
for (const [ip, prefix] of [
  ['0.0.0.0',8], ['10.0.0.0',8], ['100.64.0.0',10], ['127.0.0.0',8],
  ['169.254.0.0',16], ['172.16.0.0',12], ['192.0.0.0',24], ['192.0.2.0',24],
  ['192.31.196.0',24], ['192.52.193.0',24], ['192.88.99.0',24],
  ['192.168.0.0',16], ['192.175.48.0',24], ['198.18.0.0',15],
  ['198.51.100.0',24], ['203.0.113.0',24], ['224.0.0.0',4], ['240.0.0.0',4],
]) blocked.addSubnet(ip, prefix, 'ipv4');

export function isPublicIPv4(ip) {
  return isIP(ip) === 4 && !blocked.check(ip, 'ipv4');
}

export function validateCallback(raw) {
  let url;
  try { url = new URL(raw); } catch { throw new Error('Invalid callback URL'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.hash ||
      (url.port && url.port !== '443') || isIP(url.hostname) ||
      !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(url.hostname)) {
    throw new Error('Callback requires an HTTPS DNS hostname on port 443');
  }
  return url;
}

export function pinnedOptions(url, addresses, body, signedHeaders) {
  if (!addresses.length || addresses.some(ip => !isPublicIPv4(ip))) {
    throw new Error('Callback DNS contains unsupported or nonpublic addresses');
  }
  const headers = { Host: url.hostname, 'Content-Type': 'application/json',
    'Content-Length': String(body.length), Connection: 'close' };
  for (const name of ['webhook-id','webhook-timestamp','webhook-signature','X-MCP-Subscription-Id']) {
    const value = signedHeaders[name];
    if (typeof value !== 'string' || !value || /[\r\n]/.test(value)) throw new Error('Invalid webhook headers');
    headers[name] = value;
  }
  return {
    protocol: 'https:', hostname: addresses[0], port: 443, family: 4,
    // Literal IP pins the connection; SNI also drives Node's default hostname check.
    servername: url.hostname, rejectUnauthorized: true, agent: false,
    method: 'POST', path: url.pathname + url.search, headers, maxHeaderSize: 16384,
  };
}

// Sends already serialized/signed bytes. Does not sign, store, log, or retry.
// Caller must provide callback authorization, subscription lifecycle and idempotency.
export async function sendSignedWebhook(raw, body, signedHeaders) {
  const url = validateCallback(raw);
  if (!Buffer.isBuffer(body) || body.length > 262144) throw new Error('Invalid webhook body');
  const resolver = new Resolver({ timeout: 2500, tries: 1 });
  const addresses = await resolver.resolve4(url.hostname);
  const options = pinnedOptions(url, addresses, body, signedHeaders);
  return new Promise((resolve, reject) => {
    let timer;
    const req = request(options, res => {
      if (res.statusCode >= 300 && res.statusCode < 400) {
        res.destroy(); req.destroy(new Error('Callback redirects forbidden')); return;
      }
      let bytes = 0; const chunks = [];
      res.on('data', chunk => {
        bytes += chunk.length;
        if (bytes > 16384) { res.destroy(new Error('Callback response too large')); return; }
        chunks.push(chunk);
      });
      res.on('error', reject);
      res.on('aborted', () => reject(new Error('Callback response aborted')));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks) }));
    });
    timer = setTimeout(() => req.destroy(new Error('Callback timed out')), 10000);
    req.on('close', () => clearTimeout(timer));
    req.on('error', reject);
    req.end(body);
  });
}
