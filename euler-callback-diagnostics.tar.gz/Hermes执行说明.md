# 最小回调诊断补丁

只修改 core.mjs、webhook-transport.mjs 和新增测试。保持签名内容、HTTPS证书验证、DNS公网过滤与钉住、禁止重定向、权限、凭据及消息发送策略不变。真实微信仍关闭。无远端操作已执行。

新增返回是 JSON-RPC -32015 的 error.data.reason 固定枚举，并在收到HTTP响应时附 error.data.http_status 数字。不会输出URL、地址、secret、token、签名、响应正文或原始异常字符串。Site需要同步这些白名单才能在脱敏诊断中显示。

## 给 Hermes 的执行说明

1. 在 /home/g2391299238zyx/wechat-build/euler-wechat-gateway 中核对补丁SHA。运行 git apply --check /实际路径/callback-diagnostics.patch。即使该目录不是Git仓库，git apply也可检查/应用。若补丁不匹配，停止并报告文件名，不强行覆盖已有更改。不要读任何凭据文件。
2. 保存当前 relay 容器的镜像ID并为它增加一个未被占用的回滚标签，例如 euler-wechat-bridge-local:before-callback-diagnostics-20260930。不要覆盖已有同名回滚标签。不修改Caddy、网络、状态卷或原站点。
3. 用户确认仅更新relay后，应用 git apply /实际路径/callback-diagnostics.patch。运行 npm test（宿主机Node可用时）；Docker构建也会完整运行测试。新补丁测试合计33项。
4. 构建独立新标签，不覆盖旧镜像：docker build -t euler-wechat-bridge-local:callback-diagnostics .。这是已有Node24底图上的代码变更，不需要换Node版本。构建失败则保留正在运行的relay。
5. 新建一个不含秘密的临时Compose覆盖文件 compose.diagnostics.yaml（若已存在先停）：

```
services:
  relay:
    image: euler-wechat-bridge-local:callback-diagnostics
```

6. 先验证组合配置，然后仅替换relay：

```
docker compose -f compose.caddy.yaml -f compose.diagnostics.yaml --env-file docker.env config --quiet
docker compose -f compose.caddy.yaml -f compose.diagnostics.yaml --env-file docker.env up -d --no-build --no-deps --force-recreate relay
```

实际原部署若使用了其他覆盖文件，保留它们，但不要添加微信账户overlay。若Docker需sudo，沿用用户已批准的sudo方式，不改用户组。遵守已有UID1000/0600检查；出现锁/权限错误时报告，不删除状态或放宽权限。

7. 只回报：新旧镜像ID、relay状态、公开无凭据POST仍为401、原站仍正常、测试汇总。不要打印docker.env、容器全部环境或凭据。不要自行再创建事件订阅；由当前Euler在Site诊断就绪后发起一次受控重试。

8. 如需回滚，仅把同一覆盖文件的image改为保存的旧镜像标签，再用相同compose命令仅重建relay。保留SQLite状态卷，绝不down -v；不回滚或修改Caddy。

## 检查结果

本地33项测试通过，包括DNS/TLS/连接等错误分类、HTTP403非JSON拒绝、2xx无效JSON、挑战缺失/不符、未知异常不泄漏。额外本地TLS实测确认字面IP连接仍正确发送原域名Host/SNI，正确证书通过，错误SNI拒绝。尚未确定生产回调失败的具体原因；本补丁用于把下一次失败准确归类，不能宣称已经修复回调连接。
